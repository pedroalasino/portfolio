# INTBIZ

- **Número:** 04
- **Año:** 2024
- **Título (vista previa):** Sitio corporativo internacional
- **Descripción:** Sitio bilingüe para una consultora de negocios e IA con clientes como Coca-Cola y TN.
- **Tecnologías:** Bilingüe, Corporate, AI consulting, Analytics
- **Link:** [COMPLETAR]

## Archivos
- `logo.png` — logo (recortado de la captura del portfolio, baja resolución)
- `imagen-actual.webp` — imagen que usa hoy la card (referencia)

## Falta
- preview.webp — captura a color de la pantalla principal (1600×1000)
- link del proyecto
