# Expolajas

- **Número:** 06
- **Año:** 2026
- **Título (vista previa):** Sistema laboral con IA
- **Descripción:** Asistencia, turnos, liquidaciones y reportes de personal gestionados con IA.
- **Tecnologías:** SOBERAI, Sistema laboral, Automatización, RRHH, Reportes IA
- **Link:** [COMPLETAR]

## Archivos
- `logo.png` — logo (recortado de la captura del portfolio, baja resolución)
- `imagen-actual.webp` — imagen que usa hoy la card (referencia)

## Falta
- preview.webp — captura a color de la pantalla principal (1600×1000)
- link del proyecto
