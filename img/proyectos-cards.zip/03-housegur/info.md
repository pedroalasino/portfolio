# HouseGur

- **Número:** 03
- **Año:** 2025
- **Título (vista previa):** Inversiones inmobiliarias tokenizadas
- **Descripción:** Invertí desde €50 en propiedades de Madrid, Valencia y Alicante, con asistente IA.
- **Tecnologías:** SOBERAI, ERC-20 tokens, Fintech, Real estate
- **Link:** [COMPLETAR]

## Archivos
- `logo.png` — logo (recortado de la captura del portfolio, baja resolución)

## Falta
- preview.webp — captura a color de la pantalla principal (1600×1000)
- link del proyecto
- imagen del proyecto
