# SoberanoLab

- **Número:** 01
- **Año:** 2025
- **Título (vista previa):** Empresa de IA soberana
- **Descripción:** SOBERAI: un motor de IA que corre en tu propio equipo, sin depender de servicios externos.
- **Tecnologías:** LLaMA 3, RAG, FastAPI, Ollama, Chroma, Whisper.cpp, n8n
- **Link:** [COMPLETAR]

## Archivos
- `logo.png` — logo (blanco con fondo transparente, baja resolución)
- `imagen-actual.webp` — imagen que usa hoy la card (referencia)

## Falta
- preview.webp — captura a color de la pantalla principal (1600×1000)
- link del proyecto
