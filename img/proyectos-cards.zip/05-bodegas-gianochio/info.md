# Bodegas Gianochio

- **Número:** 05
- **Año:** 2026
- **Título (vista previa):** Sistema multi-agente
- **Descripción:** Una bodega simulada con cinco agentes de IA para capacitar equipos de Luigi Bosca.
- **Tecnologías:** Multi-agente, SOBERAI, RAG, FastAPI
- **Link:** [COMPLETAR]

## Archivos
- `logo.png` — logo (recortado de la captura del portfolio, baja resolución)
- `imagen-actual.webp` — imagen que usa hoy la card (referencia)

## Falta
- preview.webp — captura a color de la pantalla principal (1600×1000)
- link del proyecto
