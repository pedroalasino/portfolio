# LMASM Deco

- **Número:** 02
- **Año:** 2026
- **Título (vista previa):** Asesor de cortinas con realidad aumentada
- **Descripción:** Medís la ventana con la cámara del celular y la IA te recomienda la cortina con su precio.
- **Tecnologías:** Realidad aumentada (8th Wall), IA, Mercado Pago, WhatsApp API, n8n
- **Link:** https://lmasmpegau.netlify.app/

## Archivos
- `logo.png` — logo (recortado de la captura del portfolio, baja resolución)
- `preview.webp` — captura a color del proyecto
- `imagen-actual.webp` — imagen que usa hoy la card (referencia)
