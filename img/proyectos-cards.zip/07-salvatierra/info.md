# Salvatierra

- **Número:** 07
- **Año:** 2025
- **Título (vista previa):** Asistente comercial con IA
- **Descripción:** Guía a cada cliente en la elección del producto y lo acompaña en la compra.
- **Tecnologías:** SOBERAI, Asistente conversacional, RAG, E-commerce
- **Link:** [COMPLETAR]

## Archivos
- `logo.png` — logo (recortado de la captura del portfolio, baja resolución)
- `imagen-actual.webp` — imagen que usa hoy la card (referencia)

## Falta
- preview.webp — captura a color de la pantalla principal (1600×1000)
- link del proyecto
